# Databricks notebook source
# MAGIC %sql
# MAGIC select * from spotify_cata.gold.dimuser