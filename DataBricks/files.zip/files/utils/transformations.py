class reusable:
    def dropcolumns(self, df, col):
        df = df.drop(*col)
        return df